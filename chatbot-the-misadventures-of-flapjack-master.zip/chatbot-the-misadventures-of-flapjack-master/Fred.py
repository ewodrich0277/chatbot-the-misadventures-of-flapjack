if False:
    print("The hills have eyes")
else:
    print("The hills are blind")
